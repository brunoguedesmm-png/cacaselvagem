#!/usr/bin/env python3
"""Gera texturas (PNG), modelos 3D (JSON de cubos), blockstates, receitas e traducoes
do mod Caca Selvagem. Rode: python3 tools/gen_assets.py <raiz_do_projeto>"""
import json, os, random, struct, zlib, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "."
MOD = "cacaselvagem"
RES = f"{ROOT}/src/main/resources"
A = f"{RES}/assets/{MOD}"
D = f"{RES}/data/{MOD}"
rnd = random.Random(20261025)


def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False)


# ------------------------------------------------------------------ texturas
def clamp(v):
    return max(0, min(255, int(v)))


def write_png(path, px):
    h, w = len(px), len(px[0])
    raw = b"".join(b"\x00" + bytes(c for p in row for c in p) for row in px)

    def ch(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b""))


def grid(f):
    return [[f(x, y) for x in range(16)] for y in range(16)]


def steel(base, rust=0.0, tint=(0, 2, 7)):
    def f(x, y):
        if rust and rnd.random() < rust:
            return (clamp(118 + rnd.randint(-10, 10)), clamp(68 + rnd.randint(-8, 8)), 38, 255)
        v = base + rnd.randint(-8, 8) + (7 if y % 5 == 0 else 0)
        return (clamp(v + tint[0]), clamp(v + tint[1]), clamp(v + tint[2]), 255)
    return grid(f)


def wood(base):
    cols = [rnd.randint(-11, 11) for _ in range(16)]
    def f(x, y):
        v = cols[x] + rnd.randint(-4, 4) - (22 if y % 8 == 7 else 0)
        return (clamp(base[0] + v), clamp(base[1] + v * 0.8), clamp(base[2] + v * 0.6), 255)
    return grid(f)


def rope():
    def f(x, y):
        c = (178, 150, 98) if (x + y) % 4 < 2 else (138, 112, 68)
        n = rnd.randint(-6, 6)
        return (clamp(c[0] + n), clamp(c[1] + n), clamp(c[2] + n), 255)
    return grid(f)


def net():
    def f(x, y):
        if x % 4 == 0 and y % 4 == 0:
            return (120, 96, 58, 255)
        if x % 4 == 0 or y % 4 == 0:
            n = rnd.randint(-8, 8)
            return (clamp(172 + n), clamp(146 + n), clamp(100 + n), 255)
        return (0, 0, 0, 0)
    return grid(f)


def brass():
    return grid(lambda x, y: tuple(clamp(c + rnd.randint(-9, 9) + (10 if y % 4 == 0 else 0)) for c in (200, 164, 72)) + (255,))


def lens():
    def f(x, y):
        t = (x + y) / 30.0
        c = (clamp(60 + 95 * t), clamp(120 + 85 * t), clamp(185 + 45 * t))
        if (x, y) in ((3, 3), (4, 3), (3, 4)):
            c = (235, 245, 255)
        return c + (255,)
    return grid(f)


def icon(parts, outline=(30, 24, 20, 255)):
    img = [[(0, 0, 0, 0)] * 16 for _ in range(16)]
    img = [row[:] for row in img]
    for (x, y, c) in parts:
        if 0 <= x < 16 and 0 <= y < 16:
            img[y][x] = c + (255,)
    out = [row[:] for row in img]
    for y in range(16):
        for x in range(16):
            if img[y][x][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16 and img[ny][nx][3]:
                        out[y][x] = outline
                        break
    return out


def rifle_round():
    p = []
    for t in range(11):
        x, y = 2 + t, 13 - t
        if t == 0:
            col = (150, 118, 48)
        elif t <= 6:
            col = (214, 176, 80) if t % 2 else (196, 158, 66)
        else:
            col = (205, 125, 70) if t < 9 else (170, 100, 60)
        p += [(x, y, col)]
        if t <= 8:
            p += [(x + 1, y, tuple(max(0, c - 28) for c in col)), (x, y - 1, tuple(min(255, c + 22) for c in col))]
    return icon(p)


def shotgun_shell():
    p = []
    for t in range(11):
        x, y = 2 + t, 12 - t
        if t <= 3:
            col, hi = (206, 168, 74), (232, 196, 100)
        elif t <= 9:
            col, hi = (196, 40, 40), (232, 84, 74)
        else:
            col, hi = (120, 24, 24), (150, 40, 36)
        p += [(x, y, hi), (x + 1, y, col), (x, y + 1, col), (x + 1, y + 1, tuple(max(0, c - 34) for c in col))]
    return icon(p)


TB = f"{A}/textures/block"
TI = f"{A}/textures/item"
write_png(f"{TB}/trap_steel.png", steel(122, rust=0.07))
write_png(f"{TB}/trap_dark.png", steel(54))
write_png(f"{TB}/trap_wood.png", wood((112, 78, 46)))
write_png(f"{TB}/trap_rope.png", rope())
write_png(f"{TB}/trap_net.png", net())
write_png(f"{TI}/gun_blue.png", steel(36, tint=(0, 2, 9)))
write_png(f"{TI}/gun_dark.png", steel(22, tint=(0, 0, 2)))
write_png(f"{TI}/gun_steel.png", steel(142))
write_png(f"{TI}/gun_walnut.png", wood((96, 58, 34)))
write_png(f"{TI}/gun_brass.png", brass())
write_png(f"{TI}/gun_lens.png", lens())
write_png(f"{TI}/rifle_round.png", rifle_round())
write_png(f"{TI}/shotgun_shell.png", shotgun_shell())

# ------------------------------------------------------------------ modelos 3D
FACES = ["north", "east", "south", "west", "up", "down"]


def el(fr, to, tex):
    fr = [round(v, 3) for v in fr]
    to = [round(v, 3) for v in to]
    dx, dy, dz = (abs(to[i] - fr[i]) for i in range(3))
    dims = {"north": (dx, dy), "south": (dx, dy), "east": (dz, dy), "west": (dz, dy), "up": (dx, dz), "down": (dx, dz)}
    faces = {}
    for i, f in enumerate(FACES):
        wd, ht = (min(max(v, 0.5), 16) for v in dims[f])
        ox = (int(fr[0] * 3 + fr[2] * 5 + i) % int(17 - wd)) if wd < 16 else 0
        oy = (int(fr[1] * 7 + fr[2] * 3 + i) % int(17 - ht)) if ht < 16 else 0
        faces[f] = {"uv": [ox, oy, ox + wd, oy + ht], "texture": "#" + tex}
    return {"from": fr, "to": to, "faces": faces}


class M:
    def __init__(self):
        self.e = []

    def b(self, x1, y1, z1, x2, y2, z2, tex):
        self.e.append(el((x1, y1, z1), (x2, y2, z2), tex))

    def mir(self, x1, y1, z1, x2, y2, z2, tex):
        """caixa nos dois lados (espelhada em X)"""
        self.b(x1, y1, z1, x2, y2, z2, tex)
        self.b(16 - x2, y1, z1, 16 - x1, y2, z2, tex)

    def ring(self, cx, cy, cz, r, th, tex, n=16):
        import math
        for k in range(n):
            a = 2 * math.pi * k / n
            x, z = cx + r * math.cos(a), cz + r * math.sin(a)
            s = th * 0.75
            self.b(x - s, cy, z - s, x + s, cy + th, z + s, tex)

    def center(self):
        mn = [min(min(e["from"][i], e["to"][i]) for e in self.e) for i in range(3)]
        mx = [max(max(e["from"][i], e["to"][i]) for e in self.e) for i in range(3)]
        off = [8 - (mn[i] + mx[i]) / 2 for i in range(3)]
        for e in self.e:
            e["from"] = [round(e["from"][i] + off[i], 3) for i in range(3)]
            e["to"] = [round(e["to"][i] + off[i], 3) for i in range(3)]


BLOCK_DISPLAY = {
    "gui": {"rotation": [30, 225, 0], "translation": [0, -1, 0], "scale": [0.85, 0.85, 0.85]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "fixed": {"rotation": [90, 0, 0], "translation": [0, 0, -3], "scale": [0.9, 0.9, 0.9]},
    "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [0.4, 0.4, 0.4]},
    "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 0, 0], "scale": [0.45, 0.45, 0.45]},
}

# Ajuste fino: se a arma aparecer torta na mao, mude so estes numeros.
GUN_DISPLAY = {
    "gui": {"rotation": [25, 250, 0], "translation": [0, 0, 0], "scale": [0.36, 0.36, 0.36]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.3, 0.3, 0.3]},
    "fixed": {"rotation": [0, 270, 0], "translation": [0, 0, 0], "scale": [0.38, 0.38, 0.38]},
    "thirdperson_righthand": {"rotation": [90, 0, 0], "translation": [0, 1, -3], "scale": [0.5, 0.5, 0.5]},
    "firstperson_righthand": {"rotation": [0, -8, 0], "translation": [2, -2.5, -3], "scale": [0.5, 0.5, 0.5]},
}

BLOCK_TEX = {"steel": f"{MOD}:block/trap_steel", "dark": f"{MOD}:block/trap_dark", "wood": f"{MOD}:block/trap_wood",
             "rope": f"{MOD}:block/trap_rope", "net": f"{MOD}:block/trap_net"}
GUN_TEX = {"blue": f"{MOD}:item/gun_blue", "dark": f"{MOD}:item/gun_dark", "steel": f"{MOD}:item/gun_steel",
           "wood": f"{MOD}:item/gun_walnut", "brass": f"{MOD}:item/gun_brass", "lens": f"{MOD}:item/gun_lens"}


def save_block_model(name, m, cutout=False):
    tex = dict(BLOCK_TEX)
    tex["particle"] = BLOCK_TEX["steel"]
    obj = {"ambientocclusion": False, "textures": tex, "elements": m.e, "display": BLOCK_DISPLAY}
    if cutout:
        obj["render_type"] = "minecraft:cutout"
    wj(f"{A}/models/block/{name}.json", obj)


def save_gun_model(name, m):
    m.center()
    tex = dict(GUN_TEX)
    tex["particle"] = GUN_TEX["blue"]
    wj(f"{A}/models/item/{name}.json", {"textures": tex, "elements": m.e, "display": GUN_DISPLAY})


# ---------------- Armadilha de urso
def bear_common(m):
    m.b(4.5, 0, 2, 11.5, 0.8, 14, "steel")                 # placa base
    for (x, z) in ((4.8, 2.3), (10.6, 2.3), (4.8, 13.1), (10.6, 13.1)):
        m.b(x, 0.8, z, x + 0.6, 1.3, z + 0.6, "dark")       # rebites
    m.b(4.4, 0.8, 2.4, 5.2, 1.7, 13.6, "dark")              # dobradicas
    m.b(10.8, 0.8, 2.4, 11.6, 1.7, 13.6, "dark")
    for k in range(4):                                      # molas
        c = "steel" if k % 2 else "dark"
        m.mir(4.4, 0.4, 13.8 + k * 0.45, 6.6, 2.0, 14.0 + k * 0.45, c)
    m.mir(5.3, 0.9, 13.6, 5.7, 1.5, 15.8, "dark")           # eixo da mola
    m.b(7.3, 0.1, 14.0, 8.7, 0.7, 14.8, "dark")             # corrente
    m.b(7.6, 0.1, 14.8, 8.4, 0.7, 15.6, "steel")
    m.b(7.0, 0.0, 15.3, 9.0, 0.5, 16.0, "dark")


def bear_armed():
    m = M()
    bear_common(m)
    m.b(6, 0.8, 5, 10, 1.4, 11, "dark")                     # prato de pressao
    m.b(7.4, 1.4, 7.4, 8.6, 2.6, 8.6, "dark")               # gatilho
    m.b(6.6, 1.9, 7.6, 9.4, 2.4, 8.4, "steel")
    m.mir(0.8, 0.5, 2.4, 2.0, 1.5, 13.6, "steel")           # arco externo dos maxilares
    m.mir(2.0, 0.5, 2.4, 4.4, 1.5, 3.6, "steel")
    m.mir(2.0, 0.5, 12.4, 4.4, 1.5, 13.6, "steel")
    m.mir(2.0, 0.5, 7.4, 4.4, 1.5, 8.4, "dark")
    for i in range(6):                                      # dentes
        z = 3.7 + i * 1.65
        m.mir(2.0, 1.5, z, 2.9, 2.4, z + 0.8, "steel")
        m.mir(2.2, 2.4, z + 0.2, 2.7, 3.5, z + 0.6, "steel")
    for z in (3.0, 12.6):
        m.mir(1.1, 1.5, z, 1.6, 1.9, z + 0.4, "dark")
    return m


def bear_closed():
    m = M()
    bear_common(m)
    m.b(6, 0.8, 5, 10, 1.1, 11, "dark")
    for z0, z1 in ((2.4, 3.6), (12.4, 13.6)):               # bracos levantados
        for k in range(4):
            x = 4.8 + k * 0.8
            y = 1.0 + k * 0.9
            m.mir(x, y, z0, x + 1.0, y + 1.0, z1, "steel")
    m.mir(7.0, 4.0, 2.4, 8.0, 4.9, 13.6, "steel")           # arco do topo
    for i in range(6):                                      # dentes intercalados
        z = 3.6 + i * 1.65
        m.b(8.0, 3.9, z, 8.7, 4.8, z + 0.7, "steel")
        m.b(7.3, 3.9, z + 0.82, 8.0, 4.8, z + 1.52, "steel")
    m.mir(4.8, 1.0, 7.4, 6.2, 2.0, 8.4, "dark")
    m.b(7.2, 4.9, 7.4, 8.8, 5.4, 8.6, "dark")
    return m


# ---------------- Laco (snare)
def snare_common(m):
    m.b(7.4, 0, 14, 8.6, 7.2, 15.2, "wood")                 # estaca
    m.b(7.6, 7.2, 14.2, 8.4, 7.8, 15.0, "wood")
    m.b(7.0, 0, 13.6, 9.0, 0.6, 15.6, "wood")               # base raizes
    for y in (2.0, 3.6, 5.2):                               # amarras
        m.b(7.3, y, 13.9, 8.7, y + 0.5, 15.3, "rope")


def snare_armed():
    m = M()
    snare_common(m)
    m.b(7.6, 6.6, 11.0, 8.4, 7.4, 14.4, "wood")             # arvore vergada
    m.b(7.6, 6.0, 8.5, 8.4, 6.8, 11.0, "wood")
    m.b(7.6, 5.2, 7.0, 8.4, 6.0, 8.5, "wood")
    m.b(7.6, 4.4, 6.3, 8.4, 5.6, 7.2, "wood")
    m.b(7.7, 0, 9.2, 8.3, 5.2, 9.8, "wood")                 # varinha gatilho
    m.b(7.7, 4.6, 8.0, 8.3, 5.2, 9.8, "wood")
    m.b(7.2, 0.0, 8.8, 8.8, 0.5, 10.2, "wood")
    m.b(7.9, 0.7, 6.4, 8.1, 4.6, 6.6, "rope")               # corda
    m.ring(8, 0.0, 4.0, 3.0, 0.6, "rope")                   # laco no chao
    for (x, z) in ((5.0, 1.5), (11.0, 1.5), (5.5, 6.8), (10.5, 6.8)):
        m.b(x, 0, z, x + 0.5, 0.9, z + 0.5, "wood")         # gravetos de apoio
    return m


def snare_closed():
    m = M()
    snare_common(m)
    m.b(7.6, 7.8, 12.4, 8.4, 9.8, 14.4, "wood")             # arvore erguida
    m.b(7.6, 9.8, 11.4, 8.4, 11.8, 13.2, "wood")
    m.b(7.6, 11.8, 10.2, 8.4, 13.8, 12.0, "wood")
    m.b(7.6, 13.8, 9.0, 8.4, 15.8, 10.8, "wood")
    m.b(7.9, 8.4, 9.4, 8.1, 13.8, 9.6, "rope")              # corda pendurada
    m.ring(8, 6.8, 9.5, 1.3, 0.5, "rope", n=12)             # laco apertado
    m.b(6.0, 0, 6.0, 8.2, 0.6, 6.6, "wood")                 # varinha caida
    m.b(5.5, 0, 6.6, 6.5, 0.4, 7.6, "wood")
    return m


# ---------------- Rede (net)
def net_pegs(m):
    for (x, z) in ((0.6, 0.6), (13.8, 0.6), (0.6, 13.8), (13.8, 13.8)):
        m.b(x, 0, z, x + 1.6, 3.2, z + 1.6, "wood")
        m.b(x - 0.1, 2.0, z - 0.1, x + 1.7, 2.6, z + 1.7, "rope")
        m.b(x + 0.3, 3.2, z + 0.3, x + 1.3, 3.8, z + 1.3, "wood")


def net_armed():
    m = M()
    net_pegs(m)
    m.b(0.5, 0.4, 0.5, 15.5, 0.55, 15.5, "net")
    m.b(0.5, 0.9, 0.5, 15.5, 1.05, 15.5, "net")
    m.b(0.5, 0.5, 0.5, 15.5, 1.1, 1.1, "rope")
    m.b(0.5, 0.5, 14.9, 15.5, 1.1, 15.5, "rope")
    m.b(0.5, 0.5, 0.5, 1.1, 1.1, 15.5, "rope")
    m.b(14.9, 0.5, 0.5, 15.5, 1.1, 15.5, "rope")
    m.b(7.6, 0.5, 7.6, 8.4, 3.0, 8.4, "wood")               # gatilho em forquilha
    m.b(6.2, 2.4, 7.7, 9.8, 3.0, 8.3, "wood")
    m.b(6.0, 2.9, 7.6, 6.7, 3.6, 8.4, "wood")
    m.b(9.3, 2.9, 7.6, 10.0, 3.6, 8.4, "wood")
    m.b(8.0, 0.55, 8.0, 8.2, 0.7, 14.8, "rope")             # fio de disparo
    m.b(7.9, 0.5, 14.5, 8.3, 1.0, 15.0, "dark")
    return m


def net_closed():
    m = M()
    net_pegs(m)
    for (a, b_, y1, y2) in ((1.8, 14.2, 0.0, 4.2), (3.0, 13.0, 4.2, 7.2), (4.4, 11.6, 7.2, 9.6), (5.8, 10.2, 9.6, 11.4)):
        m.b(a, y1, a, b_, y2, b_, "net")
    m.b(6.6, 8.9, 6.6, 9.4, 9.8, 9.4, "rope")
    m.b(6.0, 9.6, 6.0, 10.0, 10.2, 10.0, "rope")
    m.b(7.0, 11.4, 7.0, 9.0, 12.4, 9.0, "rope")
    m.b(7.6, 12.4, 7.6, 8.4, 13.4, 8.4, "rope")
    for (x, z) in ((1.2, 1.2), (14.0, 1.2), (1.2, 14.0), (14.0, 14.0)):
        m.b(x, 0.5, z, x + 0.8, 1.0, z + 0.8, "rope")
    m.b(6.4, 0.0, 7.0, 9.6, 0.4, 7.6, "wood")
    return m


# ---------------- Rifle de caca (bolt-action com luneta)
def rifle():
    m = M()
    b = m.b
    b(7.2, 9.0, -8, 8.8, 10.6, 12, "blue")                    # cano
    b(6.9, 8.7, -9, 9.1, 10.9, -6.5, "dark")                  # freio de boca
    b(6.8, 8.6, -8.2, 9.2, 11.0, -7.8, "dark")
    b(7.7, 10.6, -7, 8.3, 11.6, -6.4, "steel")                # massa de mira
    b(6.9, 8.2, 2, 9.1, 10.0, 12, "wood")                     # guarda-mao
    b(6.8, 8.1, 5, 9.2, 10.1, 5.8, "brass")                   # abracadeiras
    b(6.8, 8.1, 9.5, 9.2, 10.1, 10.3, "brass")
    b(6.7, 7.2, 4, 7.0, 8.2, 11, "wood")                      # arredondamento inferior
    b(9.0, 7.2, 4, 9.3, 8.2, 11, "wood")
    b(6.6, 7.8, 12, 9.4, 10.8, 20, "blue")                    # caixa da culatra
    b(6.5, 7.6, 12, 9.5, 8.0, 20, "dark")
    b(7.0, 10.8, 14, 9.0, 10.95, 18.4, "dark")                # janela de ejecao
    b(9.4, 9.0, 14.2, 9.55, 10.4, 17.6, "dark")
    b(7.3, 10.8, 16, 8.7, 11.4, 21.5, "steel")                # ferrolho
    b(8.7, 10.9, 19.2, 10.6, 11.5, 20.0, "steel")             # cabo do ferrolho
    b(10.6, 10.5, 19.0, 11.6, 11.9, 20.4, "dark")
    b(7.5, 10.9, 21.5, 8.5, 11.5, 22.3, "dark")
    b(7.4, 11.6, 9, 8.6, 12.8, 19, "dark")                    # luneta: tubo
    b(7.1, 11.3, 8, 8.9, 13.1, 10.5, "dark")                  # objetiva
    b(7.2, 11.4, 19, 8.8, 12.9, 21, "dark")                   # ocular
    b(7.3, 11.5, 7.7, 8.7, 12.9, 8.0, "lens")
    b(7.4, 11.6, 21.0, 8.6, 12.8, 21.15, "lens")
    b(7.7, 12.8, 13.5, 8.3, 13.5, 14.5, "steel")              # torre elevacao
    b(8.6, 12.0, 13.5, 9.3, 12.6, 14.5, "steel")              # torre vento
    b(7.0, 11.7, 14.4, 8.0, 12.7, 15.6, "dark")               # anel de ajuste
    for z in (10.6, 16.6):                                    # aneis e bases da luneta
        b(7.2, 11.5, z, 8.8, 13.0, z + 0.8, "blue")
        b(7.4, 10.8, z, 8.6, 11.5, z + 0.8, "blue")
    b(7.4, 6.8, 13.5, 8.6, 7.2, 18.5, "dark")                 # guarda-mato
    b(7.4, 6.8, 13.5, 8.6, 7.9, 14.0, "dark")
    b(7.4, 6.8, 18.0, 8.6, 7.9, 18.5, "dark")
    b(7.7, 7.2, 15.5, 8.3, 8.0, 16.0, "steel")                # gatilho
    b(7.0, 6.4, 9, 9.0, 7.8, 13.5, "blue")                    # caixa do carregador
    b(6.9, 6.0, 9, 9.1, 6.4, 13.5, "brass")
    b(7.1, 6.0, 17.5, 8.9, 8.6, 20.0, "wood")                 # empunhadura
    b(7.0, 7.2, 20.0, 9.0, 10.2, 25.0, "wood")                # coronha
    b(7.2, 10.2, 22.0, 8.8, 10.8, 27.0, "wood")              # apoio de bochecha
    b(7.0, 6.2, 25.0, 9.0, 10.2, 29.0, "wood")
    b(7.0, 5.4, 29.0, 9.0, 10.0, 31.0, "wood")
    b(6.95, 5.3, 31.0, 9.05, 9.9, 32.0, "dark")               # coxim
    b(6.7, 7.0, 12.4, 7.1, 7.5, 12.9, "brass")                # fixador de bandoleira
    b(6.9, 7.0, 28.0, 7.3, 7.5, 28.5, "brass")
    return m


# ---------------- Espingarda pump-action
def shotgun():
    m = M()
    b = m.b
    b(7.2, 9.0, -10, 8.8, 10.4, 12, "blue")                   # cano
    b(7.0, 8.8, -10.6, 9.0, 10.6, -9.6, "dark")               # choke
    b(7.6, 10.4, -9, 8.4, 10.7, 12, "steel")                  # trilho de mira
    b(7.7, 10.7, -9.6, 8.3, 11.3, -9.0, "brass")              # mira
    b(7.3, 7.8, -4, 8.7, 9.0, 10, "blue")                     # tubo do carregador
    b(7.2, 7.7, -4.4, 8.8, 9.1, -4.0, "brass")
    b(6.8, 7.4, 3, 9.2, 9.2, 9.5, "wood")                     # pump
    for z in (3.6, 4.8, 6.0, 7.2, 8.4):
        b(6.75, 7.6, z, 9.25, 9.0, z + 0.35, "dark")
    b(6.7, 7.8, 12, 9.3, 10.6, 19.5, "blue")                  # receptor
    b(6.6, 7.6, 12, 9.4, 8.0, 19.5, "dark")
    b(9.3, 8.6, 14, 9.45, 10.0, 17.2, "dark")                 # janela de ejecao
    b(7.0, 10.6, 13, 9.0, 10.75, 18, "dark")
    b(6.5, 8.6, 18.0, 6.7, 10.0, 19.0, "steel")               # trava de seguranca
    b(7.4, 6.8, 13.5, 8.6, 7.2, 18.5, "dark")                 # guarda-mato
    b(7.4, 6.8, 13.5, 8.6, 7.9, 14.0, "dark")
    b(7.4, 6.8, 18.0, 8.6, 7.9, 18.5, "dark")
    b(7.7, 7.2, 15.5, 8.3, 8.0, 16.0, "steel")                # gatilho
    b(7.1, 6.2, 18.5, 8.9, 8.6, 21.0, "wood")                 # empunhadura
    b(7.0, 7.4, 19.5, 9.0, 10.4, 25.0, "wood")                # coronha
    b(7.0, 6.4, 25.0, 9.0, 10.2, 29.0, "wood")
    b(7.0, 5.6, 29.0, 9.0, 10.0, 31.0, "wood")
    b(6.95, 5.5, 31.0, 9.05, 9.9, 32.0, "dark")
    b(6.7, 7.0, -3.0, 7.1, 7.6, -2.5, "brass")
    b(6.9, 7.0, 28.0, 7.3, 7.5, 28.5, "brass")
    return m


# ------------------------------------------------------------------ salvar tudo
traps = {
    "bear_trap": (bear_armed, bear_closed, False),
    "snare_trap": (snare_armed, snare_closed, False),
    "net_trap": (net_armed, net_closed, True),
}
ROT = {"north": 0, "east": 90, "south": 180, "west": 270}
for name, (fa, fc, cut) in traps.items():
    save_block_model(f"{name}_armed", fa(), cutout=cut)
    save_block_model(f"{name}_closed", fc(), cutout=cut)
    variants = {}
    for facing, y in ROT.items():
        for armed in ("true", "false"):
            v = {"model": f"{MOD}:block/{name}_{'armed' if armed == 'true' else 'closed'}"}
            if y:
                v["y"] = y
            variants[f"armed={armed},facing={facing}"] = v
    wj(f"{A}/blockstates/{name}.json", {"variants": variants})
    wj(f"{A}/models/item/{name}.json", {"parent": f"{MOD}:block/{name}_armed"})
    wj(f"{D}/loot_tables/blocks/{name}.json", {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MOD}:{name}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

save_gun_model("hunting_rifle", rifle())
save_gun_model("pump_shotgun", shotgun())
for n in ("rifle_round", "shotgun_shell"):
    wj(f"{A}/models/item/{n}.json", {"parent": "item/generated", "textures": {"layer0": f"{MOD}:item/{n}"}})

# ------------------------------------------------------------------ receitas
def shaped(name, pattern, key, result, count=1):
    wj(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shaped", "category": "equipment", "pattern": pattern,
                                    "key": key, "result": {"item": f"{MOD}:{name}", "count": count}})


def shapeless(name, ings, count):
    wj(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shapeless", "category": "equipment",
                                    "ingredients": [{"item": i} for i in ings],
                                    "result": {"item": f"{MOD}:{name}", "count": count}})


iron = {"item": "minecraft:iron_ingot"}
planks = {"tag": "minecraft:planks"}
shaped("hunting_rifle", ["  G", "III", "WW "], {"G": {"item": "minecraft:glass_pane"}, "I": iron, "W": planks}, None)
shaped("pump_shotgun", ["III", "  W", " WW"], {"I": iron, "W": planks}, None)
shapeless("rifle_round", ["minecraft:gunpowder", "minecraft:copper_ingot", "minecraft:iron_nugget"], 4)
shapeless("shotgun_shell", ["minecraft:gunpowder", "minecraft:paper", "minecraft:iron_nugget"], 4)
shaped("bear_trap", ["I I", "IPI", "ICI"], {"I": iron, "P": {"item": "minecraft:stone_pressure_plate"}, "C": {"item": "minecraft:chain"}}, None)
shaped("snare_trap", ["SS ", "ST ", "  T"], {"S": {"item": "minecraft:stick"}, "T": {"item": "minecraft:string"}}, None)
shaped("net_trap", ["TTT", "TST", "TTT"], {"S": {"item": "minecraft:stick"}, "T": {"item": "minecraft:string"}}, None)

# ------------------------------------------------------------------ traducoes
pt = {
    "itemGroup.cacaselvagem": "Caça Selvagem",
    "item.cacaselvagem.hunting_rifle": "Rifle de Caça",
    "item.cacaselvagem.pump_shotgun": "Espingarda Pump",
    "item.cacaselvagem.rifle_round": "Munição de Rifle",
    "item.cacaselvagem.shotgun_shell": "Cartucho de Espingarda",
    "block.cacaselvagem.bear_trap": "Armadilha de Urso",
    "block.cacaselvagem.snare_trap": "Laço de Caça",
    "block.cacaselvagem.net_trap": "Armadilha de Rede",
    "tooltip.cacaselvagem.damage": "Dano: %s x%s",
    "tooltip.cacaselvagem.ammo": "Munição: %s",
    "tooltip.cacaselvagem.trap": "Agache e use para desarmar. Use para rearmar.",
}
en = {
    "itemGroup.cacaselvagem": "Wild Hunt",
    "item.cacaselvagem.hunting_rifle": "Hunting Rifle",
    "item.cacaselvagem.pump_shotgun": "Pump Shotgun",
    "item.cacaselvagem.rifle_round": "Rifle Round",
    "item.cacaselvagem.shotgun_shell": "Shotgun Shell",
    "block.cacaselvagem.bear_trap": "Bear Trap",
    "block.cacaselvagem.snare_trap": "Hunting Snare",
    "block.cacaselvagem.net_trap": "Net Trap",
    "tooltip.cacaselvagem.damage": "Damage: %s x%s",
    "tooltip.cacaselvagem.ammo": "Ammo: %s",
    "tooltip.cacaselvagem.trap": "Sneak + use to disarm. Use to re-arm.",
}
wj(f"{A}/lang/pt_br.json", pt)
wj(f"{A}/lang/en_us.json", en)
wj(f"{RES}/pack.mcmeta", {"pack": {"description": "Caça Selvagem", "pack_format": 15}})
print("ok")
