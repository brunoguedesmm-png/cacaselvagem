package com.cacaselvagem.registry;

import com.cacaselvagem.CacaSelvagem;
import com.cacaselvagem.block.TrapBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, CacaSelvagem.MODID);

    private static BlockBehaviour.Properties props(MapColor color, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(2.0F).sound(sound)
                .noOcclusion().noCollission().pushReaction(PushReaction.DESTROY);
    }

    // Armadilha de urso: fere e prende por 10 s
    public static final RegistryObject<Block> BEAR_TRAP = BLOCKS.register("bear_trap",
            () -> new TrapBlock(props(MapColor.METAL, SoundType.CHAIN), Block.box(0, 0, 0, 16, 5, 16), 6.0F, 200, false));

    // Laco: nao fere, prende por 15 s
    public static final RegistryObject<Block> SNARE_TRAP = BLOCKS.register("snare_trap",
            () -> new TrapBlock(props(MapColor.WOOD, SoundType.WOOD), Block.box(2, 0, 1, 14, 8, 16), 0.0F, 300, false));

    // Rede: nao fere, prende e enfraquece por 10 s
    public static final RegistryObject<Block> NET_TRAP = BLOCKS.register("net_trap",
            () -> new TrapBlock(props(MapColor.COLOR_BROWN, SoundType.GRASS), Block.box(0, 0, 0, 16, 4, 16), 0.0F, 200, true));
}
