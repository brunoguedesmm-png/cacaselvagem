package com.cacaselvagem.registry;

import com.cacaselvagem.CacaSelvagem;
import com.cacaselvagem.item.GunItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CacaSelvagem.MODID);

    public static final RegistryObject<Item> RIFLE_ROUND = ITEMS.register("rifle_round",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SHOTGUN_SHELL = ITEMS.register("shotgun_shell",
            () -> new Item(new Item.Properties()));

    // ammo, dano, projeteis, dispersao, cooldown(ticks), alcance, recuo, tom do som
    public static final RegistryObject<Item> HUNTING_RIFLE = ITEMS.register("hunting_rifle",
            () -> new GunItem(new Item.Properties().stacksTo(1).durability(500),
                    RIFLE_ROUND, 16.0F, 1, 0.0F, 35, 128.0, 3.0F, 1.1F));
    public static final RegistryObject<Item> PUMP_SHOTGUN = ITEMS.register("pump_shotgun",
            () -> new GunItem(new Item.Properties().stacksTo(1).durability(350),
                    SHOTGUN_SHELL, 4.0F, 8, 0.09F, 24, 24.0, 4.5F, 0.8F));

    public static final RegistryObject<Item> BEAR_TRAP = ITEMS.register("bear_trap",
            () -> new BlockItem(ModBlocks.BEAR_TRAP.get(), new Item.Properties()));
    public static final RegistryObject<Item> SNARE_TRAP = ITEMS.register("snare_trap",
            () -> new BlockItem(ModBlocks.SNARE_TRAP.get(), new Item.Properties()));
    public static final RegistryObject<Item> NET_TRAP = ITEMS.register("net_trap",
            () -> new BlockItem(ModBlocks.NET_TRAP.get(), new Item.Properties()));
}
