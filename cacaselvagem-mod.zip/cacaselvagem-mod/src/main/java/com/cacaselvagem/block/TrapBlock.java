package com.cacaselvagem.block;

import java.util.List;
import javax.annotation.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Armadilha generica: prende (e opcionalmente fere) qualquer ser vivo que pise nela. */
public class TrapBlock extends Block {
    public static final BooleanProperty ARMED = BooleanProperty.create("armed");
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    private final VoxelShape shape;
    private final float damage;
    private final int rootTicks;
    private final boolean weaken;

    public TrapBlock(Properties props, VoxelShape shape, float damage, int rootTicks, boolean weaken) {
        super(props);
        this.shape = shape;
        this.damage = damage;
        this.rootTicks = rootTicks;
        this.weaken = weaken;
        registerDefaultState(stateDefinition.any().setValue(ARMED, true).setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ARMED, FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @SuppressWarnings("deprecation")
    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return shape;
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    @SuppressWarnings("deprecation")
    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState other, LevelAccessor level,
                                  BlockPos pos, BlockPos otherPos) {
        return !state.canSurvive(level, pos) ? Blocks.AIR.defaultBlockState()
                : super.updateShape(state, dir, other, level, pos, otherPos);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !state.getValue(ARMED)) return;
        if (!(entity instanceof LivingEntity living) || living.isSpectator()) return;

        level.setBlock(pos, state.setValue(ARMED, false), 3);
        if (damage > 0) living.hurt(level.damageSources().generic(), damage);
        living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, rootTicks, 6, false, true));
        living.addEffect(new MobEffectInstance(MobEffects.JUMP, rootTicks, 128, false, false));
        if (weaken) living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, rootTicks, 1, false, true));
        level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0F, 0.6F);
        if (damage > 0) level.playSound(null, pos, SoundEvents.CHAIN_BREAK, SoundSource.BLOCKS, 0.8F, 0.8F);
    }

    @SuppressWarnings("deprecation")
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        boolean armed = state.getValue(ARMED);
        if (!armed || player.isShiftKeyDown()) {
            level.setBlock(pos, state.setValue(ARMED, !armed), 3);
            level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 0.8F, armed ? 0.7F : 1.2F);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable BlockGetter level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.cacaselvagem.trap").withStyle(ChatFormatting.GRAY));
    }
}
