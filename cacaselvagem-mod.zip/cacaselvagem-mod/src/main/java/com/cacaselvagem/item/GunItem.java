package com.cacaselvagem.item;

import java.util.List;
import java.util.function.Supplier;
import javax.annotation.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Arma de fogo "hitscan": consome municao do inventario, tem recuo, cooldown e desgaste. */
public class GunItem extends Item {
    private final Supplier<Item> ammo;
    private final float damage;
    private final int pellets;
    private final float spread;
    private final int cooldown;
    private final double range;
    private final float recoil;
    private final float pitch;

    public GunItem(Properties props, Supplier<Item> ammo, float damage, int pellets, float spread,
                   int cooldown, double range, float recoil, float pitch) {
        super(props);
        this.ammo = ammo;
        this.damage = damage;
        this.pellets = pellets;
        this.spread = spread;
        this.cooldown = cooldown;
        this.range = range;
        this.recoil = recoil;
        this.pitch = pitch;
    }

    private int findAmmo(Player player) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (!s.isEmpty() && s.is(ammo.get())) return i;
        }
        return -1;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack gun = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;
        int slot = creative ? -1 : findAmmo(player);

        if (!creative && slot < 0) {
            if (!level.isClientSide) {
                level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0F, 1.2F);
            }
            return InteractionResultHolder.fail(gun);
        }

        player.getCooldowns().addCooldown(this, cooldown);
        if (level.isClientSide) {
            player.setXRot(player.getXRot() - recoil); // recuo da mira
        } else {
            if (!creative) player.getInventory().getItem(slot).shrink(1);
            fire(level, player);
            gun.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.sidedSuccess(gun, level.isClientSide());
    }

    private void fire(Level level, Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        RandomSource rnd = level.getRandom();

        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.GENERIC_EXPLODE,
                SoundSource.PLAYERS, 0.6F, pitch * 1.6F);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CROSSBOW_SHOOT,
                SoundSource.PLAYERS, 0.8F, pitch * 0.6F);
        if (level instanceof ServerLevel sl) {
            Vec3 muzzle = eye.add(look.scale(1.2));
            sl.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y - 0.15, muzzle.z, 6, 0.05, 0.05, 0.05, 0.01);
            sl.sendParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y - 0.15, muzzle.z, 2, 0.02, 0.02, 0.02, 0.01);
        }

        for (int i = 0; i < pellets; i++) {
            Vec3 dir = look.add((rnd.nextDouble() - 0.5) * 2 * spread, (rnd.nextDouble() - 0.5) * 2 * spread,
                    (rnd.nextDouble() - 0.5) * 2 * spread).normalize();
            Vec3 end = eye.add(dir.scale(range));
            BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, player));
            Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
            AABB box = new AABB(eye, stop).inflate(1.0);
            EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, player, eye, stop, box,
                    e -> !e.isSpectator() && e.isPickable() && e != player);
            if (eh != null) {
                if (eh.getEntity() instanceof LivingEntity le) le.invulnerableTime = 0; // todos os chumbinhos acertam
                eh.getEntity().hurt(level.damageSources().playerAttack(player), damage);
                stop = eh.getLocation();
            }
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.CRIT, stop.x, stop.y, stop.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.cacaselvagem.damage", String.format("%.0f", damage), pellets)
                .withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("tooltip.cacaselvagem.ammo", ammo.get().getDescription())
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
