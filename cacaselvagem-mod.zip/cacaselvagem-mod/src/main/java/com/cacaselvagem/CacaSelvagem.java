package com.cacaselvagem;

import com.cacaselvagem.registry.ModBlocks;
import com.cacaselvagem.registry.ModItems;
import com.cacaselvagem.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CacaSelvagem.MODID)
public class CacaSelvagem {
    public static final String MODID = "cacaselvagem";

    public CacaSelvagem() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
    }
}
